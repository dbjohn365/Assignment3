<?php # PROCESS MESSAGE POST.

# Access session.
session_start();

# Make load function available.
require ( 'login_tools.php' ) ;

# Redirect if not logged in.
if ( !isset( $_SESSION[ 'user_id' ] ) ) { load() ; }

# Set page title and display header section.
$page_title = 'Like Add' ;
include ( 'includes/header.html' ) ;

# Declaring and initializing the user id and post id variables and their values
$user_id = $_SESSION['user_id'];
$post_id = $_GET['id'];

# Check form submitted.
if ($post_id != null)
{
  require ( 'connect_db.php' ) ;

  $query = "SELECT * FROM likes WHERE post_id = '$post_id'";
  $result = mysqli_query($dbc, $query);

  

  if($row = mysqli_fetch_array( $result, MYSQLI_ASSOC ) > 0){
    while($row = mysqli_fetch_array( $result, MYSQLI_ASSOC )){
      $val = 0;
      # Checking if the user has liked the current post
      # Execute inserting into 'likes' database table.
  
      if(($row['user_id'] == $_SESSION['user_id']) && $row['count'] == 1){
        load('forum.php');
      }else if(($row['user_id'] != $_SESSION['user_id']) && $row['count'] > 0){
        $val = $row['count'] + 1;
        $q = "UPDATE likes SET count = '.$val.' WHERE post_id = $post_id";
        $r = mysqli_query ( $dbc, $q ) ;
  
        load('forum.php');
      
        # Report error on failure.
        if (mysqli_affected_rows($dbc) != 1) { echo '<p>Error</p>'.mysqli_error($dbc); } else { load('forum.php');}
      }else{
        $q = "INSERT INTO likes(post_id,user_id, count) 
                VALUES ('$post_id','$user_id', 1)";
        $r = mysqli_query ( $dbc, $q ) ;
  
        load('forum.php');
      
        # Report error on failure.
        if (mysqli_affected_rows($dbc) != 1) { echo '<p>Error</p>'.mysqli_error($dbc); } else { load('forum.php');}
      }
    }
  }else{
    $q = "INSERT INTO likes(post_id,user_id, count) 
            VALUES ('$post_id','$user_id', 1)";
    $r = mysqli_query ( $dbc, $q ) ;

    load('forum.php');
  
    # Report error on failure.
    if (mysqli_affected_rows($dbc) != 1) { echo '<p>Error</p>'.mysqli_error($dbc); } else { load('forum.php');}
  }
}

    # Close database connection.
    mysqli_close( $dbc ) ; 
 
 
# Create a hyperlink back to the forum page.
echo '<p><a href="forum.php">Forum</a>' ;
 
# Display footer section.
include ( 'includes/footer.html' ) ;

?>