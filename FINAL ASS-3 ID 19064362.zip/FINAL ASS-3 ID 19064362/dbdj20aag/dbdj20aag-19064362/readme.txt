1) unzip this to a folder below your web root (data/localweb in easyphp or /htdocs in mamp or xampp)
2) in phpMyAdmin locally, create a new database called site_db
3) select that database (site_db) and then choose "import" and select the file site_db.sql
4) then run this site - register, log in, look at the products, put a few in the cart, check out, add a comment to a forum, then log out - see how you find it
5) then start doing assignment 2