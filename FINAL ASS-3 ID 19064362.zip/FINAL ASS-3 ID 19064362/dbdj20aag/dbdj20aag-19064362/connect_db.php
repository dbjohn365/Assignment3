<?php
if (strpos($_SERVER['SERVER_NAME'], "pedro") !== false)
{
$dbc = mysqli_connect("pedro.cs.herts.ac.uk", "dj20aag", "DWMTtR3V", "dbdj20aag")
OR die(mysqli_connect_error());
}
else
{
//for mamp users its "root","root" rather than "root",""
$dbc = mysqli_connect("localhost", "root", "", "site_db") 
OR die(mysqli_connect_error());
}


# Set encoding to match PHP script encoding.
mysqli_set_charset( $dbc, 'utf8' ) ;
?>