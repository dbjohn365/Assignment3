<?php # DISPLAY COMPLETE PRODUCTS PAGE.

# Access session.
session_start() ;

# Redirect if not logged in.
if ( !isset( $_SESSION[ 'user_id' ] ) ) { require ( 'login_tools.php' ) ; load() ; }

# Set page title and display header section.
$page_title = 'Shop' ;
include ( 'includes/header.html' ) ;
error_reporting(0);
$sorter = $_GET['type'];

if(isset($sorter) && ($sorter == "Ascending")){
  echo '<div>Sort cost from Largest - Smallest using the link: <a href="shop.php?type='."Descending".'">Sort</a> </div>';
}else{
  echo '<div>Sort cost from Smallest - Largest using the link: <a href="shop.php?type='."Ascending".'">Sort</a> </div>';
}

# Open database connection.
require ( 'connect_db.php' ) ;

# Retrieve items from 'shop' database table.
if($_GET['type'] == "Ascending"){
  $q = "SELECT * FROM shop ORDER BY item_price ASC" ;

  $r = mysqli_query( $dbc, $q ) ;
  if ( mysqli_num_rows( $r ) > 0 )
  {
    # Display body section.
    echo '<div>';
    while ( $row = mysqli_fetch_array( $r, MYSQLI_ASSOC ))
    {
      echo '<strong>' . $row['item_name'] .'</strong><br><span style="font-size:smaller">'. $row['item_desc'] . '</span><br><a href="detail.php?id='.$row['item_id'].'"><img src='. $row['item_img'].'></a><br>$' . $row['item_price'] . '<br><a href="added.php?id='.$row['item_id'].'">Add To Cart</a><br><br><hr>';
    }
    echo '</div>';
    
    # Close database connection.
    mysqli_close( $dbc ) ; 
  }
}else if($_GET['type'] == "Descending"){
  $q = "SELECT * FROM shop ORDER BY item_price DESC" ;
  $r = mysqli_query( $dbc, $q ) ;
  if ( mysqli_num_rows( $r ) > 0 )
  {
    # Display body section.
    echo '<div>';
    while ( $row = mysqli_fetch_array( $r, MYSQLI_ASSOC ))
    {
      echo '<strong>' . $row['item_name'] .'</strong><br><span style="font-size:smaller">'. $row['item_desc'] . '</span><br><a href="detail.php?id='.$row['item_id'].'"><img src='. $row['item_img'].'></a><br>$' . $row['item_price'] . '<br><a href="added.php?id='.$row['item_id'].'">Add To Cart</a><br><br><hr>';
    }
    echo '</div>';

    $sort = "Ascending";
    
    # Close database connection.
    mysqli_close( $dbc ) ; 
  }
}else if(!($_GET['type'] == "Descending" && $_GET['type'] == "Ascending")){
  $q = "SELECT * FROM shop" ;
  $r = mysqli_query( $dbc, $q ) ;
  if ( mysqli_num_rows( $r ) > 0 )
  {
    # Display body section.
    echo '<div>';
    while ( $row = mysqli_fetch_array( $r, MYSQLI_ASSOC ))
    {
      echo '<strong>' . $row['item_name'] .'</strong><br><span style="font-size:smaller">'. $row['item_desc'] . '</span><br><a href="detail.php?id='.$row['item_id'].'"><img src='. $row['item_img'].'></a><br>$' . $row['item_price'] . '<br><a href="added.php?id='.$row['item_id'].'">Add To Cart</a><br><br><hr>';
    }
    echo '</div>';
    
    # Close database connection.
    mysqli_close( $dbc ) ; 
  }
}else{
  # Or display message.
  echo '<p>There are currently no items in this shop.</p>' ;
  
  # Close database connection.
  mysqli_close( $dbc ) ; 
}

# Create navigation links.
echo '<p><a href="cart.php">View Cart</a> | <a href="forum.php">Forum</a> | <a href="home.php">Home</a> | <a href="goodbye.php">Logout</a></p>' ;

# Display footer section.
include ( 'includes/footer.html' ) ;

?>