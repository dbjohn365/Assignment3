<?php # DISPLAY COMPLETE FORUM PAGE.

# Access session.
session_start() ;

# Redirect if not logged in.
if ( !isset( $_SESSION[ 'user_id' ] ) ) { require ( 'login_tools.php' ) ; load() ; } else {

# Set page title and display header section.
$page_title = 'Forum' ;
include ( 'includes/header.html' ) ;

# Open database connection.
require ( 'connect_db.php' ) ;

# Display body section, retrieving from 'forum' database table.
$q = "SELECT * FROM forum" ;
$r = mysqli_query( $dbc, $q ) ;
$unlike = "unlike";
if ( mysqli_num_rows( $r ) > 0 )
{
  while ( $row = mysqli_fetch_array( $r, MYSQLI_ASSOC ))
  {
    $count = 0;
    $p_id = $row['post_id'];//Getting the post_id for each row to be used to check in the likes table
    $likes_check = "SELECT * FROM likes";
    $likes_check_result = mysqli_query($dbc, $likes_check);
    $likes_query = "SELECT * FROM likes WHERE post_id = '$p_id'";
    $likes_result = mysqli_query($dbc, $likes_query);
    $likes_results = mysqli_fetch_array( $likes_result, MYSQLI_ASSOC );
    echo '<div><span style="display: inline-block; min-width: 10%;">Posted By: ' . $row['first_name'] .' '. $row['last_name'] . '</span><br><span>Date: '. $row['post_date'].'</span><br><span>Subject: ' . $row['subject'] . '</span><br><br><span>' . $row['message'] . '</span><br><span> ';

    if($likes_check_result){
      echo "<span>Likes </span>";
      if($likes_result){
        if( ($likes_results !== null) && ($likes_results['user_id'] == $_SESSION['user_id']) && $likes_results['count'] == 1){
          $count += 1;
          echo '<a type="button" href="unlike_action.php?id='.$row['post_id'].'&user='.$_SESSION["user_id"].'">Unlike</a> &nbsp;';
        }else if(($likes_results !== null) && ($likes_results['user_id'] != $_SESSION['user_id']) && $likes_results['count'] == 1){
          $count += 1;
          echo '<a type="button" href="like_action.php?id='.$row['post_id'].'">Like</a> &nbsp;';
        }else{
          echo '<a type="button" href="like_action.php?id='.$row['post_id'].'">Like</a>';
        }
      }  
    }else{
      echo '<a type="button" href="like_action.php?id='.$row['post_id'].'">Like</a>';
    }

    echo '</span><hr></div>';
  }
}
else { echo '<p>There are currently no messages.</p>' ; }

# Create navigation links.
echo '<p><a href="post.php">Post Message</a> | <a href="shop.php">Shop</a> | <a href="home.php">Home</a> | <a href="goodbye.php">Logout</a></p>' ;

echo '';
}
# Close database connection.
mysqli_close( $dbc ) ;
  
# Display footer section.
include ( 'includes/footer.html' ) ;

?>