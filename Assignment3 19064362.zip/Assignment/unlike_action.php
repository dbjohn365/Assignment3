<?php # PROCESS MESSAGE POST.

# Access session.
session_start();

# Make load function available.
require ( 'login_tools.php' ) ;

# Redirect if not logged in.
if ( !isset( $_SESSION[ 'user_id' ] ) ) { load() ; }

# Set page title and display header section.
$page_title = 'Like Add' ;
include ( 'includes/header.html' ) ;

# Declaring and initializing the user id and post id variables and their values
$user = $_SESSION['user_id'];
$post_id = $_GET['id'];
// $name = $_GET['unlike'];

# Check form submitted.
if ($post_id != null)
{
  require ( 'connect_db.php' ) ;

  $query = "SELECT * FROM likes WHERE post_id = '$post_id'";
  $result = mysqli_query($dbc, $query);

  while($row = mysqli_fetch_array( $result, MYSQLI_ASSOC )){
    # Checking if the user has liked the current post
    # Execute delete 'likes' from the database table.

    $search_post_id = $row['post_id'];
    $search_for_post_status = "SELECT * FROM likes WHERE post_id = '$search_post_id'";//Querying for the right post
    $search_result = mysqli_query( $dbc, $query);

    while($search_row = mysqli_fetch_array( $search_result, MYSQLI_ASSOC )){
      $search_id = $search_row['id'];
      if(($search_row['user_id'] == $_SESSION['user_id']) && $search_row['count'] == 1){//Checking if the like was done by the user
        $q = "DELETE FROM likes WHERE id = '$search_id'";
        $r = mysqli_query ( $dbc, $q ) ;
    
        # Report error on failure.
        if (mysqli_affected_rows($dbc) != 1) { echo '<p>Error</p>'.mysqli_error($dbc); } else { load('forum.php');}
      }else if(($search_row['user_id'] == $_SESSION['user_id']) && $search_row['count'] == 0){
        load('forum.php');
      }
    }
  }

    # Close database connection.
    mysqli_close( $dbc ) ; 
 }  
 
# Create a hyperlink back to the forum page.
echo '<p><a href="forum.php">Forum</a>' ;
 
# Display footer section.
include ( 'includes/footer.html' ) ;

?>